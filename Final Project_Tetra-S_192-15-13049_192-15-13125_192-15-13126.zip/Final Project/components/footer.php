<footer class="footer">
   <section class="grid">
      <div class="box">
         <h3>Follow Our Contact Links</h3>
         <a href="#"><i class="fas fa-phone"></i> +8801733541333</a>
         <a href="#"><i class="fas fa-phone"></i> +8801303301483</a>
         <a href="https://accounts.google.com/signin/v2/identifier?continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&service=mail&sacu=1&rip=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin"><i class="fas fa-envelope"></i> tetra-s@gmail.com</a>
         <a href="https://www.google.com/maps"><i class="fas fa-map-marker-alt"></i> Dhanmondi 32, Sukrabad </a>
      </div>
      <div class="box">
         <h3>Follow Our Social Links</h3>
         <a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i>Facebook Page</a>
         <a href="https://twitter.com/"><i class="fab fa-twitter"></i>Twitter Page</a>
         <a href="https://www.instagram.com/"><i class="fab fa-instagram"></i>Instagram Page</a>
         <a href="https://www.linkedin.com/"><i class="fab fa-linkedin"></i>Linkedin Page</a>
      </div>
   </secTion>
   <div class="credit">&copy;Copyright @ <?= date('M, Y'); ?> By <span>Tetra-S</span> | All Rights Reserved!</div>
</footer>