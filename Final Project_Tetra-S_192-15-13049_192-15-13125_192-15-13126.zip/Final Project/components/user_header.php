<?php
   if(isset($message)){
      foreach($message as $message){
         echo '
         <div class="message">
            <span>'.$message.'</span>
            <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
         </div>
         ';
      }
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style>
      .header {
         position: sticky;
         top: 0;
         left: 0;
         right: 0;
         background-color: #dcfafc;
         box-shadow: var(--box-shadow);
         z-index: 1000;
      }
   </style>
</head>
<body>
   <!-- User Header Section Starts -->
   <header class="header">
      <section class="flex">
         <a href="home.php" class="logo"><span>E-RCos</span></a>
         <nav class="navbar">
            <a href="home.php">Home</a>
            <a href="about.php">About</a>
            <a href="orders.php">Orders</a>
            <a href="shop.php">Shop</a>
            <a href="contact.php">Message</a>
         </nav>
         <div class="icons">
            <?php
               $count_wishlist_items = $conn->prepare("SELECT * FROM `wishlist` WHERE user_id = ?");
               $count_wishlist_items->execute([$user_id]);
               $total_wishlist_counts = $count_wishlist_items->rowCount();

               $count_cart_items = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
               $count_cart_items->execute([$user_id]);
               $total_cart_counts = $count_cart_items->rowCount();
            ?>
            <div id="menu-btn" class="fas fa-bars"></div>
            <a href="search_page.php"><i class="fa-brands fa-searchengin"></i></a>
            <a href="wishlist.php"><i class="fa-brands fa-gratipay"></i><span>(<?= $total_wishlist_counts; ?>)</span></a>
            <a href="cart.php"><i class="fa-brands fa-opencart"></i><span>(<?= $total_cart_counts; ?>)</span></a>
            <div id="user-btn" class="fa-regular fa-user"></div>
         </div>
         <div class="profile">
            <?php          
               $select_profile = $conn->prepare("SELECT * FROM `users` WHERE id = ?");
               $select_profile->execute([$user_id]);
               if($select_profile->rowCount() > 0){
               $fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);
            ?>
            <p><?= $fetch_profile["name"]; ?></p>
            <div class="flex-btn">
               <a href="user_register.php" class="option-btn">Register</a>
               <a href="user_login.php" class="option-btn">Login</a>
            </div>
            <a href="components/user_logout.php" class="delete-btn" onclick="return confirm('Logout From The Website?');">Logout</a> 
            <?php
               }else{
            ?>
            <p>Please Login/Register First!</p>
            <div class="flex-btn">
               <a href="user_register.php" class="option-btn">Register</a>
               <a href="user_login.php" class="option-btn">Login</a>
            </div>
            <?php
               }
            ?>      
         </div>
      </section>
   </header>
<!-- User Header Section Ends -->
</body>
</html>