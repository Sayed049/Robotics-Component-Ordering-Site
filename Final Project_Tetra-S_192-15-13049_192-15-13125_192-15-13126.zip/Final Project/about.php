<?php
include 'components/connect.php';
session_start();
if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>About</title>

   <!-- Swipper CSS File Link -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
   
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/user_style.css">

</head>
<body>
<?php include 'components/user_header.php'; ?>

<!-- About Section Starts -->
<section class="about">
   <div class="row">
      <div class="image">
         <img src="images/about-img.jpg" alt="">
      </div>
      <div class="content">
         <h3>Why Choose us?</h3>
         <p class="perspective">Because any student those who are interested in robotics can buy robotics component in our website easiy with a reasonable price.</p>
         <a href="contact.php" class="btn">Contact For More Info.</a>
      </div>
   </div>
</section>
<!-- About Section Ends -->

<!-- Reviews Section Starts -->
<section class="reviews">
   <h1 class="heading">Client's Reviews</h1>
   <div class="swiper reviews-slider">
   <div class="swiper-wrapper">
      <div class="swiper-slide slide">
         <p>"My order was quickly processed and shipped. All with email notifications. Order confirmation and Order shipped are the same day or next day. Awesome"</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Rozob Ali</h3>
      </div>
      <div class="swiper-slide slide">
         <p>"The service is always exceptional, and the range of parts match the service. Order confirmation and Order shipped are the same day or next day"</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Sourov</h3>
      </div>
      <div class="swiper-slide slide">
         <p>"Fast shipping, well packed, very good quality products. Order confirmation and Order shipped are the same day or next day with reasonable price"</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Province</h3>
      </div>
      <div class="swiper-slide slide">
         <p>"My order was quickly processed and shipped. All with email notifications. Order confirmation and Order shipped are the same day or next day. Awesome"</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Halima</h3>
      </div>
      <div class="swiper-slide slide">
         <p>"The service is always exceptional, and the range of parts match the service. Order confirmation and Order shipped are the same day or next day"</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Maynul</h3>
      </div>
      <div class="swiper-slide slide">
         <p>"Fast shipping, well packed, very good quality products. Order confirmation and Order shipped are the same day or next day with reasonable price"</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Asif</h3>
      </div>
   </div>
   <div class="swiper-pagination"></div>
   </div>
</section>
<!-- Reviews Section Ends -->

<?php include 'components/footer.php'; ?>

<!-- Swipper JS File Link -->
<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>

<!-- Custom JS File Link -->
<script src="js/script.js"></script>

<script>
var swiper = new Swiper(".reviews-slider", {
   loop:true,
   spaceBetween: 20,
   pagination: {
      el: ".swiper-pagination",
      clickable:true,
   },
   breakpoints: {
      0: {
        slidesPerView:1,
      },
      768: {
        slidesPerView: 2,
      },
      991: {
        slidesPerView: 3,
      },
   },
});
</script>

</body>
</html>